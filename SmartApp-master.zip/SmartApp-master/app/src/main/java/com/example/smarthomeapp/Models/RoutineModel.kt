package com.example.smarthomeapp.Models

data class RoutineModel (val id: Int, val routineName: String, val lastRun: String)